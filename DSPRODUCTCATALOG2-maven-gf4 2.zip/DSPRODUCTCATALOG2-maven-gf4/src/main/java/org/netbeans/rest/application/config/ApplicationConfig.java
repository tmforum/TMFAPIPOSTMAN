package org.netbeans.rest.application.config;

import javax.ws.rs.ApplicationPath;
import org.glassfish.jersey.server.ResourceConfig;

/**
 *
 * @author pierregauthier
 *
 */
@ApplicationPath("api/catalogManagement/v2")
public class ApplicationConfig extends ResourceConfig {

    public ApplicationConfig() {
        packages ("org.codehaus.jackson.jaxrs");
        
        register(org.tmf.dsmapi.jaxrs.resource.hub.CatalogHubResource.class);
        register(org.tmf.dsmapi.catalog.service.catalog.CatalogFacadeREST.class);
        register(org.tmf.dsmapi.catalog.service.category.CategoryFacadeREST.class);
        register(org.tmf.dsmapi.catalog.service.category.CategoryInCatalogIdFacadeREST.class);
        register(org.tmf.dsmapi.catalog.service.category.CategoryInCatalogIdVersionFacadeREST.class);
        register(org.tmf.dsmapi.catalog.service.productOffering.ProductOfferingFacadeREST.class);
        register(org.tmf.dsmapi.catalog.service.productOffering.ProductOfferingInCatalogIdFacadeREST.class);
        register(org.tmf.dsmapi.catalog.service.productOffering.ProductOfferingInCatalogIdVersionFacadeREST.class);
        register(org.tmf.dsmapi.catalog.service.productSpecification.ProductSpecificationFacadeREST.class);
        register(org.tmf.dsmapi.catalog.service.productSpecification.ProductSpecificationInCatalogIdFacadeREST.class);
        register(org.tmf.dsmapi.catalog.service.productSpecification.ProductSpecificationInCatalogIdVersionFacadeREST.class);
        
        register(org.tmf.dsmapi.commons.jaxrs.provider.BadUsageExceptionMapper.class);
        register(org.tmf.dsmapi.commons.jaxrs.provider.JacksonConfigurator.class);
        register(org.tmf.dsmapi.commons.jaxrs.provider.JsonMappingExceptionMapper.class);
        register(org.tmf.dsmapi.commons.jaxrs.provider.UnknowResourceExceptionMapper.class);
    }

}
