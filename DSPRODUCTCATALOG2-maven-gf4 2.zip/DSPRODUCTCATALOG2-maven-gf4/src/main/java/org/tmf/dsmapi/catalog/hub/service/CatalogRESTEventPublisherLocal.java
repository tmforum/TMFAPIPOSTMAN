package org.tmf.dsmapi.catalog.hub.service;

import javax.ejb.Local;
import org.tmf.dsmapi.catalog.hub.model.CatalogEvent;
import org.tmf.dsmapi.hub.model.Hub;

@Local
public interface CatalogRESTEventPublisherLocal {

    public void publish(Hub hub, CatalogEvent event);
    
}
